package ship.ship_game;

import java.util.ArrayList;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import model.*;

/**
 * Ein Beispiel wie ein Grid erzeugt wird und wie der gedrueckte Button
 * identifiziert wird
 */
public class App extends Application implements EventHandler<ActionEvent> {

	Label l = new Label();
	static Playground p = new Playground(10, 10);
	Control control = new Control();

	@Override
	public void start(Stage primaryStage) {
		BorderPane root = new BorderPane();
		GridPane center = new GridPane();
		for (int i = 0; i < p.getPlayground().length; i++) {
			for (int j = 0; j < p.getPlayground()[i].length; j++) {
				String bStr = String.format(p.getPlayground()[j][i].print()); // wie printf
				Button b = new Button(bStr);
				b.setOnAction(control);
				b.setUserData(p.getPlayground()[j][i]);
				center.add(b, i, j); // stelle den Button an die Stelle i,j
			}
		}
		root.setCenter(center);
		root.setBottom(l);
		Scene scene = new Scene(root, 640, 480);
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	public static void main(String[] args) {
		
		ArrayList<Ship> ships = new ArrayList<Ship>();
		// Schlachtschiff
		for (int i = 0; i < 1; i++) {
			ships.add(new Ship(5));
		}

		// Zerstörer
		for (int i = 0; i < 3; i++) {
			ships.add(new Ship(3));
		}

		// Kreuzer
		for (int i = 0; i < 2; i++) {
			ships.add(new Ship(4));
		}

		// U-Boote
		for (int i = 0; i < 4; i++) {
			ships.add(new Ship(2));
		}
		
		p.initPlayground();
		p = ShipFactory.create(p, ships);
		System.out.println(p);
		
		launch();
	}
}