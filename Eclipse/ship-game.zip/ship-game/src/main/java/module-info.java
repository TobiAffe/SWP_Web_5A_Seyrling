module ship.ship_game {
    requires javafx.controls;
    exports ship.ship_game;
}
