package model;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

public class Control implements EventHandler<ActionEvent> {

    @Override
    public void handle(ActionEvent event) {
        Button n = (Button) event.getSource();
        Field f = (Field) n.getUserData();

        f.setVisible(true);
        n.setText(f.print());

        if (f instanceof ShipPart) {
            ShipPart part = (ShipPart) f;
            if (part.getShip().isSunk()) {
                System.out.println("Schiff zerstört");
            } else {
                System.out.println("Schiff nicht zerstört");
            }
        }
    }
}